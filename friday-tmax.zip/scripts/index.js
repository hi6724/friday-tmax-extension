function areDatesInSameWeek(dateString1, dateString2) {
  const getDateOfMonday = (date) => {
    const dayOfWeek = date.getDay();
    const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek; // 일요일인 경우 특별 처리
    const monday = new Date(date);
    monday.setDate(monday.getDate() + mondayOffset);
    return monday;
  };

  const date1 = new Date(dateString1);
  const date2 = new Date(dateString2);

  // 각 날짜의 해당 주 월요일 구하기
  const monday1 = getDateOfMonday(date1);
  const monday2 = getDateOfMonday(date2);

  // 주 시작 날짜(월요일) 비교
  return (
    monday1.toISOString().split('T')[0] === monday2.toISOString().split('T')[0]
  );
}

function calculateTimeDifference(startTime, endTime, holiday) {
  const MEAL_TIME = 60;
  const HALF_DAY_WORKTIME = 240;
  // 시간과 분을 분리하여 정수로 변환
  const [startHours, startMinutes] = startTime.split(':').map(Number);
  const [endHours, endMinutes] = endTime.split(':').map(Number);

  // 전체 시간을 분으로 변환
  const startTotalMinutes = startHours * 60 + startMinutes;
  const endTotalMinutes = endHours * 60 + endMinutes;
  let workTime = endTotalMinutes - startTotalMinutes - MEAL_TIME;
  // 20시 이후 퇴근하면 저녁시간 1시간 추가로 제외
  if (endHours >= 20) workTime -= MEAL_TIME;

  // 반차 시간 계산
  if (holiday === '반차(오후)') workTime += HALF_DAY_WORKTIME;
  if (holiday === '반차(오전)') workTime += HALF_DAY_WORKTIME + MEAL_TIME;

  return workTime;
}

function convertMinutesToHHMM(minutes) {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;

  // 시간과 분을 HH:MM 형식으로 포맷팅
  const formattedHours = hours.toString().padStart(2, '0');
  const formattedMinutes = mins.toString().padStart(2, '0');

  return `${formattedHours}:${formattedMinutes}`;
}

setInterval(() => {
  const bodyDocument = document.querySelector('#frameBody')?.contentDocument;
  if (!bodyDocument) return;

  const listTable = bodyDocument.getElementById('listTable');
  if (!listTable) return;
  const trList = listTable.querySelectorAll('tr');
  if (!trList) return;

  let sumList = [];
  let appendIndexList = [];

  trList.forEach((tr, i) => {
    if (i === 0) return;
    const prevTdElement = trList[i - 1].querySelectorAll('td');
    const tdElement = tr.querySelectorAll('td');

    if (!tdElement) return;
    const prevDate = prevTdElement[7].innerText;
    const date = tdElement[7].innerText;

    if (!date || !prevDate) return;
    const startTime = tdElement[9].innerText;
    const endTime = tdElement[12].innerText;
    const isHoliday = tdElement[15].innerText;
    const workTime = calculateTimeDifference(startTime, endTime, isHoliday);
    tdElement[14].innerText = convertMinutesToHHMM(workTime);

    // 첫 element
    if (i === 1) sumList.push(0);
    else if (!areDatesInSameWeek(date, prevDate)) {
      sumList.push(0);
      appendIndexList.push(appendIndexList.length + i - 1);
    }
    sumList[sumList.length - 1] += workTime;
    if (i === trList.length - 1)
      appendIndexList.push(appendIndexList.length + trList.length - 1);
  });

  appendIndexList.forEach((index, idx) => {
    const newTr = document.createElement('tr');
    newTr.innerHTML = `
      <tr class="td01_data_C odd" style="cursor:default; line-height: 1.6;">
        <td class="testClass">-1</td>
        <td align="left">티맥스핀테크</td>
        <td align="left">FT2-1팀</td>
        <td align="center" style="cursor:pointer;" onclick="fn_CommonEmpView('2023602', '4118');">2023602</td>
        <td style="cursor:pointer;" onclick="fn_CommonEmpView('2023602', '4118');">하훈목</td>
        <td>연구원</td>
        <td>N</td>
        <td></td>
        <td></td>
        <td>09:24</td>
        <td></td>
        <td></td>
        <td></td>
        <td class="colorCell">3</td>
        <td>${convertMinutesToHHMM(sumList[idx])}</td>
        <td></td>
        <td><span class="erpCommonBtn lnk"></span></td>
        <td></td>
        <td align="left"><div class="wrap"><textarea placeholder="비고란을 입력하세요." onkeyup="textareaResize(this)" style="width: 99%; height: auto;" value="" onchange="fn_update_remark(2,this.value)"></textarea></div></td>
        <input type="hidden" name="statusEmp" id="statusEmp" value="2023602">
        <input type="hidden" name="statusDate" id="statusDate" value="20231212">
        <input type="hidden" name="statusKind" id="statusKind" value="01">
        <input type="hidden" name="empCls_2" id="empCls_2" value="01">
        <input type="hidden" id="rowIdx2" name="rowIdx">
      </tr>
    `;
    listTable.children[1].insertBefore(
      newTr,
      listTable.children[1].children[index]
    );
  });
}, 500);
